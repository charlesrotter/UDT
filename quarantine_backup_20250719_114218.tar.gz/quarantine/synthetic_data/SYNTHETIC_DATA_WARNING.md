# ⚠️ SYNTHETIC DATA WARNING ⚠️

**These files use synthetic/artificial data instead of real observations**

## ❌ PROBLEMATIC FILES IN THIS DIRECTORY:
- `artifact_corrected_supernova_analysis_unbiased.py` - Uses sample data instead of real supernovae
- `test_quantum_experimental_simulation.py` - Generates synthetic quantum experiments

## 🚨 SCIENTIFIC ISSUES:
1. **No real observational validation** - Results cannot be trusted
2. **Artificial parameter tuning** - May accidentally favor UDT
3. **Publication invalidity** - Peer review would reject synthetic data claims

## ✅ USE THESE INSTEAD:
- Real supernova data: `scripts/analyze_supernovae_raw.py`
- Real quantum data: `quantum_validation/pure_geometric_muon_g2_test.py`

**NEVER USE SYNTHETIC DATA FOR UDT VALIDATION**